<script lang="ts">let { children } = $props();</script>
<svelte:head><meta name="theme-color" content="#087e78"/><meta name="description" content="منصة موعدي الطبي لحجز المواعيد الطبية"/></svelte:head>
{@render children()}
<style>:global(*){box-sizing:border-box}:global(body){margin:0;background:#f4f8f7;color:#173b39;font-family:Tahoma,Arial,sans-serif;direction:rtl}:global(button),:global(input){font:inherit}</style>
