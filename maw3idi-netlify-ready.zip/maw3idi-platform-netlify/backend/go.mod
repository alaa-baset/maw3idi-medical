module maw3idi/backend

go 1.23

require (
 github.com/go-chi/chi/v5 v5.2.1
 github.com/jackc/pgx/v5 v5.7.2
 github.com/golang-jwt/jwt/v5 v5.2.1
)
