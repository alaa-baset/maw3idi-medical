package main

import (
	"context"
	"encoding/json"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"github.com/golang-jwt/jwt/v5"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

type app struct {
	db        *pgxpool.Pool
	jwtSecret []byte
}
type claims struct {
	Role string `json:"role"`
	jwt.RegisteredClaims
}
type ctxKey string

const userIDKey ctxKey = "userID"
const roleKey ctxKey = "role"

type clinicInput struct {
	Name        string `json:"name"`
	Type        string `json:"type"`
	City        string `json:"city"`
	Address     string `json:"address"`
	Phone       string `json:"phone"`
	Description string `json:"description"`
}
type bookingInput struct {
	DoctorID       string  `json:"doctorId"`
	SlotID         string  `json:"slotId"`
	PaymentMethod  string  `json:"paymentMethod"`
	PaymentChannel string  `json:"paymentChannel"`
	AmountDue      float64 `json:"amountDue"`
	AmountPaid     float64 `json:"amountPaid"`
	Note           string  `json:"note"`
}
type doctorInput struct {
	ClinicID        string  `json:"clinicId"`
	FullName        string  `json:"fullName"`
	Specialty       string  `json:"specialty"`
	Bio             string  `json:"bio"`
	ConsultationFee float64 `json:"consultationFee"`
}
type slotInput struct {
	DoctorID string    `json:"doctorId"`
	StartsAt time.Time `json:"startsAt"`
	EndsAt   time.Time `json:"endsAt"`
}

func main() {
	dbURL := os.Getenv("DATABASE_URL")
	secret := os.Getenv("JWT_SECRET")
	if dbURL == "" || len(secret) < 32 {
		log.Fatal("DATABASE_URL and JWT_SECRET (at least 32 chars) are required")
	}
	ctx := context.Background()
	db, err := pgxpool.New(ctx, dbURL)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	if err = db.Ping(ctx); err != nil {
		log.Fatal(err)
	}
	a := &app{db: db, jwtSecret: []byte(secret)}
	r := chi.NewRouter()
	r.Use(middleware.RequestID, middleware.RealIP, middleware.Recoverer, middleware.Timeout(15*time.Second))
	r.Get("/health", func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, 200, map[string]string{"status": "ok"}) })
	r.Get("/api/clinics", a.listClinics)
	r.Group(func(pr chi.Router) {
		pr.Use(a.auth)
		pr.Post("/api/admin/clinics", a.createClinic)
		pr.Post("/api/admin/doctors", a.createDoctor)
		pr.Post("/api/admin/slots", a.createSlot)
		pr.Post("/api/admin/clinics/{id}/publish", a.publishClinic)
		pr.Post("/api/admin/bookings/{id}/verify-payment", a.verifyPayment)
		pr.Get("/api/me/bookings", a.myBookings)
		pr.Post("/api/bookings", a.createBooking)
		pr.Get("/api/doctor/bookings", a.doctorBookings)
	})

	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}
	log.Printf("Maw3idi API listening on :%s", port)
	log.Fatal(http.ListenAndServe(":"+port, r))
}

func (a *app) auth(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := strings.TrimSpace(strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer "))
		if h == "" {
			writeError(w, 401, "يلزم تسجيل الدخول")
			return
		}
		t, err := jwt.ParseWithClaims(h, &claims{}, func(t *jwt.Token) (any, error) { return a.jwtSecret, nil })
		if err != nil || !t.Valid {
			writeError(w, 401, "جلسة غير صالحة")
			return
		}
		c, ok := t.Claims.(*claims)
		if !ok || c.Subject == "" {
			writeError(w, 401, "رمز الدخول غير صالح")
			return
		}
		ctx := context.WithValue(r.Context(), userIDKey, c.Subject)
		ctx = context.WithValue(ctx, roleKey, c.Role)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}
func role(r *http.Request) string { v, _ := r.Context().Value(roleKey).(string); return v }
func uid(r *http.Request) string  { v, _ := r.Context().Value(userIDKey).(string); return v }
func (a *app) createClinic(w http.ResponseWriter, r *http.Request) {
	if role(r) != "platform_admin" {
		writeError(w, 403, "إنشاء العيادات متاح لمالك المنصة فقط")
		return
	}
	var in clinicInput
	if json.NewDecoder(r.Body).Decode(&in) != nil || strings.TrimSpace(in.Name) == "" || strings.TrimSpace(in.City) == "" || strings.TrimSpace(in.Address) == "" || (in.Type != "clinic" && in.Type != "medical_center") {
		writeError(w, 400, "بيانات العيادة غير مكتملة")
		return
	}
	var id string
	err := a.db.QueryRow(r.Context(), `INSERT INTO clinics(name,clinic_type,city,address,phone,description,created_by) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`, in.Name, in.Type, in.City, in.Address, in.Phone, in.Description, uid(r)).Scan(&id)
	if err != nil {
		writeError(w, 500, "تعذر إنشاء العيادة")
		return
	}
	writeJSON(w, 201, map[string]string{"id": id, "message": "تم إنشاء العيادة"})
}
func (a *app) createDoctor(w http.ResponseWriter, r *http.Request) {
	if role(r) != "platform_admin" {
		writeError(w, 403, "إضافة الأطباء متاحة لمالك المنصة فقط")
		return
	}
	var in doctorInput
	if json.NewDecoder(r.Body).Decode(&in) != nil || in.ClinicID == "" || strings.TrimSpace(in.FullName) == "" || strings.TrimSpace(in.Specialty) == "" {
		writeError(w, 400, "بيانات الطبيب غير مكتملة")
		return
	}
	var id string
	err := a.db.QueryRow(r.Context(), `INSERT INTO doctors(clinic_id,full_name,specialty,bio,consultation_fee) VALUES($1,$2,$3,$4,$5) RETURNING id`, in.ClinicID, in.FullName, in.Specialty, in.Bio, in.ConsultationFee).Scan(&id)
	if err != nil {
		writeError(w, 500, "تعذر إضافة الطبيب؛ تحقق من وجود العيادة")
		return
	}
	writeJSON(w, 201, map[string]string{"id": id, "message": "تمت إضافة الطبيب"})
}
func (a *app) createSlot(w http.ResponseWriter, r *http.Request) {
	if role(r) != "platform_admin" {
		writeError(w, 403, "إضافة المواعيد متاحة لمالك المنصة فقط")
		return
	}
	var in slotInput
	if json.NewDecoder(r.Body).Decode(&in) != nil || in.DoctorID == "" || !in.EndsAt.After(in.StartsAt) || !in.StartsAt.After(time.Now()) {
		writeError(w, 400, "بيانات الفترة الزمنية غير صحيحة")
		return
	}
	var id string
	err := a.db.QueryRow(r.Context(), `INSERT INTO doctor_slots(doctor_id,starts_at,ends_at) VALUES($1,$2,$3) RETURNING id`, in.DoctorID, in.StartsAt, in.EndsAt).Scan(&id)
	if err != nil {
		writeError(w, 500, "تعذر إضافة الموعد")
		return
	}
	writeJSON(w, 201, map[string]string{"id": id, "message": "تمت إضافة الفترة الزمنية"})
}
func (a *app) publishClinic(w http.ResponseWriter, r *http.Request) {
	if role(r) != "platform_admin" {
		writeError(w, 403, "نشر العيادات متاح لمالك المنصة فقط")
		return
	}
	tag, err := a.db.Exec(r.Context(), `UPDATE clinics SET is_published=true WHERE id=$1`, chi.URLParam(r, "id"))
	if err != nil || tag.RowsAffected() == 0 {
		writeError(w, 404, "العيادة غير موجودة")
		return
	}
	writeJSON(w, 200, map[string]string{"message": "تم نشر العيادة"})
}
func (a *app) verifyPayment(w http.ResponseWriter, r *http.Request) {
	if role(r) != "platform_admin" {
		writeError(w, 403, "تأكيد المدفوعات متاح لمالك المنصة فقط")
		return
	}
	var in struct {
		AmountPaid float64 `json:"amountPaid"`
	}
	if json.NewDecoder(r.Body).Decode(&in) != nil || in.AmountPaid <= 0 {
		writeError(w, 400, "قيمة الدفعة غير صحيحة")
		return
	}
	tx, err := a.db.BeginTx(r.Context(), pgx.TxOptions{})
	if err != nil {
		writeError(w, 500, "تعذر تنفيذ العملية")
		return
	}
	defer tx.Rollback(r.Context())
	var method, status, slotID, doctorID string
	var starts time.Time
	var due float64
	err = tx.QueryRow(r.Context(), `SELECT payment_method,payment_status,slot_id,doctor_id,starts_at,amount_due FROM bookings WHERE id=$1 FOR UPDATE`, chi.URLParam(r, "id")).Scan(&method, &status, &slotID, &doctorID, &starts, &due)
	if err != nil {
		writeError(w, 404, "الحجز غير موجود")
		return
	}
	if status != "pending_payment_review" && status != "pending_gateway" {
		writeError(w, 409, "هذا الحجز ليس بانتظار تأكيد الدفع")
		return
	}
	if in.AmountPaid > due {
		writeError(w, 400, "المبلغ المدفوع أكبر من قيمة الحجز")
		return
	}
	finalPay := "paid"
	if method == "deposit" {
		finalPay = "deposit_paid"
	}
	_, err = tx.Exec(r.Context(), `UPDATE bookings SET payment_status=$2,booking_status='confirmed',amount_paid=$3,updated_at=now() WHERE id=$1`, chi.URLParam(r, "id"), finalPay, in.AmountPaid)
	if err != nil {
		writeError(w, 409, "الفترة الزمنية لم تعد متاحة؛ لم يتم تأكيد الحجز")
		return
	}
	_, _ = tx.Exec(r.Context(), `INSERT INTO payment_events(booking_id,channel,amount,status,verified_by) SELECT id,payment_channel,$2,'verified',$3 FROM bookings WHERE id=$1`, chi.URLParam(r, "id"), in.AmountPaid, uid(r))
	if err = tx.Commit(r.Context()); err != nil {
		writeError(w, 500, "تعذر حفظ تأكيد الدفع")
		return
	}
	writeJSON(w, 200, map[string]string{"message": "تم التحقق من الدفع وتأكيد الحجز"})
}

func (a *app) listClinics(w http.ResponseWriter, r *http.Request) {
	rows, err := a.db.Query(r.Context(), `SELECT id,name,clinic_type,city,address,phone,description FROM clinics WHERE is_published=true ORDER BY name`)
	if err != nil {
		writeError(w, 500, "تعذر تحميل العيادات")
		return
	}
	defer rows.Close()
	out := []map[string]any{}
	for rows.Next() {
		var id, name, typ, city, address, phone, desc string
		if rows.Scan(&id, &name, &typ, &city, &address, &phone, &desc) == nil {
			out = append(out, map[string]any{"id": id, "name": name, "type": typ, "city": city, "address": address, "phone": phone, "description": desc})
		}
	}
	writeJSON(w, 200, out)
}
func (a *app) createBooking(w http.ResponseWriter, r *http.Request) {
	if role(r) != "patient" {
		writeError(w, 403, "الحجز متاح لحسابات المرضى فقط")
		return
	}
	var in bookingInput
	if json.NewDecoder(r.Body).Decode(&in) != nil {
		writeError(w, 400, "بيانات الحجز غير صالحة")
		return
	}
	if in.PaymentMethod != "full" && in.PaymentMethod != "deposit" && in.PaymentMethod != "unpaid" {
		writeError(w, 400, "طريقة الحجز غير صحيحة")
		return
	}
	if in.PaymentChannel != "local_transfer" && in.PaymentChannel != "gateway" && in.PaymentChannel != "none" {
		writeError(w, 400, "قناة الدفع غير صحيحة")
		return
	}
	if in.PaymentMethod == "unpaid" {
		in.PaymentChannel = "none"
		in.AmountPaid = 0
	}
	if in.PaymentMethod != "unpaid" && in.PaymentChannel == "none" {
		writeError(w, 400, "اختر وسيلة الدفع")
		return
	}
	tx, err := a.db.BeginTx(r.Context(), pgx.TxOptions{})
	if err != nil {
		writeError(w, 500, "تعذر بدء الحجز")
		return
	}
	defer tx.Rollback(r.Context())
	var clinicID, doctorID string
	var starts time.Time
	var open bool
	err = tx.QueryRow(r.Context(), `SELECT d.clinic_id,d.id,s.starts_at,s.is_open FROM doctor_slots s JOIN doctors d ON d.id=s.doctor_id WHERE s.id=$1 AND d.id=$2 AND d.is_active FOR UPDATE OF s`, in.SlotID, in.DoctorID).Scan(&clinicID, &doctorID, &starts, &open)
	if err != nil || !open {
		writeError(w, 409, "هذا الموعد غير متاح")
		return
	}
	status, payStatus := "waitlist", "not_required"
	if in.PaymentMethod != "unpaid" {
		status = "pending_confirmation"
		if in.PaymentChannel == "local_transfer" {
			payStatus = "pending_payment_review"
		} else {
			payStatus = "pending_gateway"
		}
	}
	var id string
	err = tx.QueryRow(r.Context(), `INSERT INTO bookings(patient_id,clinic_id,doctor_id,slot_id,starts_at,payment_method,payment_channel,payment_status,booking_status,amount_due,amount_paid,patient_note) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`, uid(r), clinicID, doctorID, in.SlotID, starts, in.PaymentMethod, in.PaymentChannel, payStatus, status, in.AmountDue, in.AmountPaid, in.Note).Scan(&id)
	if err != nil {
		writeError(w, 409, "تعذر تسجيل الحجز؛ ربما تم حجز الموعد للتو")
		return
	}
	if err = tx.Commit(r.Context()); err != nil {
		writeError(w, 500, "تعذر حفظ الحجز")
		return
	}
	writeJSON(w, 201, map[string]any{"id": id, "bookingStatus": status, "paymentStatus": payStatus, "message": "تم تسجيل طلب الحجز"})
}
func (a *app) myBookings(w http.ResponseWriter, r *http.Request) {
	a.bookingsFor(w, r, `b.patient_id=$1`, uid(r))
}
func (a *app) doctorBookings(w http.ResponseWriter, r *http.Request) {
	if role(r) != "doctor" && role(r) != "clinic_staff" {
		writeError(w, 403, "غير مصرح")
		return
	}
	a.bookingsFor(w, r, `d.user_id=$1`, uid(r))
}
func (a *app) bookingsFor(w http.ResponseWriter, r *http.Request, where, arg string) {
	q := `SELECT b.id,b.starts_at,b.booking_status,b.payment_method,b.payment_status,c.name,d.full_name,u.full_name FROM bookings b JOIN clinics c ON c.id=b.clinic_id JOIN doctors d ON d.id=b.doctor_id JOIN users u ON u.id=b.patient_id WHERE ` + where + ` ORDER BY b.starts_at`
	rows, err := a.db.Query(r.Context(), q, arg)
	if err != nil {
		writeError(w, 500, "تعذر تحميل الحجوزات")
		return
	}
	defer rows.Close()
	out := []map[string]any{}
	for rows.Next() {
		var id, status, method, pstatus, clinic, doctor, patient string
		var at time.Time
		if rows.Scan(&id, &at, &status, &method, &pstatus, &clinic, &doctor, &patient) == nil {
			out = append(out, map[string]any{"id": id, "startsAt": at, "bookingStatus": status, "paymentMethod": method, "paymentStatus": pstatus, "clinic": clinic, "doctor": doctor, "patient": patient})
		}
	}
	writeJSON(w, 200, out)
}
func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func writeError(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}

func cors(origin string) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if origin != "" {
				w.Header().Set("Access-Control-Allow-Origin", origin)
				w.Header().Set("Vary", "Origin")
				w.Header().Set("Access-Control-Allow-Headers", "Authorization, Content-Type")
				w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
			}
			if r.Method == http.MethodOptions {
				w.WriteHeader(http.StatusNoContent)
				return
			}
			next.ServeHTTP(w, r)
		})
	}
}
